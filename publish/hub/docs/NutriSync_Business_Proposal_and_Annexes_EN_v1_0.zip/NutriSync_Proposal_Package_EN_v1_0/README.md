# NutriSync business proposal package — English v1.0

## Start here

`02_Tony_Answers` contains the one-page meeting handout in Word, PDF and Markdown. `01_Detailed_Proposal` contains the detailed 21-page proposal with Annexes A–J. `03_Planning_Workbook` contains seven formula-driven planning sheets: Read me, Funding, Marketing, GTM inputs, GTM illustration, Return illustration and Sources.

The business position is founder-led progress with or without external investment, within committed capacity. The financing levels—EUR 15–25K, EUR 250–350K, EUR 2M and EUR 5M—represent different prospective scopes, not additive demands or validated valuations.

## Source coverage

The annex folder includes eight complete source documents/exports plus the original user-supplied screenshot. The current pitch deck, innovation presentations, rebuilt financial workbook and legal set are represented by explicitly labelled reference briefs/extracts, not their full source binaries. See `04_Source_Annexes/SOURCE_REGISTER.md` and `.csv` for every title, source locator, use and treatment.

All historical originals retain their original claims and dates for traceability; inclusion does not endorse those claims as current or validated. The Google Sheets finance export is not the rebuilt financial workbook. No original deck, Canva design or legal master was overwritten.

## Financial and legal status

The new budget and acquisition workbook is an illustrative planning schedule, not a full operating/cash-flow model or a repaired historical forecast. It deliberately shows that the tested paid-acquisition assumptions do not justify scaled advertising. Valuation and return figures are illustrative, include loss cases and are not offered investment terms or guaranteed returns.

Australia and Singapore are markets to explore, not committed launches. Lucía's PR status and digital-sector contacts are founder-provided context. Government support is eligibility-dependent and is not assumed as secured cash. Legal, clinical, privacy and country-launch decisions need the appropriate professional review.

Prepared as a discussion draft for founder approval. No communication was sent to Tony or any prospective partner.
