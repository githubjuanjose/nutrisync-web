# NutriSync source-annex register

Full originals are unchanged copies or a full native export. Reference briefs preserve usable source material but are not substitutes for the original binaries. The latter items were available as File Library references rather than mounted source files.

## S01 — NutriSync_Proposal_32_v8_Consolidated_Spain_Market_and_Wearable_Strategy.docx

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S01_Proposal_32_v8.docx](Full_Originals/S01_Proposal_32_v8.docx)  
**Source locator:** https://docs.google.com/document/d/1ub944wLwYx3BjXRH3NvUJgc4_AealCUY/edit  
**Use:** Product, market and cloud/wearable architecture; 12 August 2026 draft

## S01a — NutriSync_Proposal_32_v4_Daily_Intelligence_Spain_First.html

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S01a_Proposal_32_v4.html](Full_Originals/S01a_Proposal_32_v4.html)  
**Source locator:** https://drive.google.com/file/d/1kaLTNj2nAbX-rqEp2RK6mdh-VToPrsv8/view  
**Use:** Historical product and trust baseline

## S02 — NutriSync PPT Aug 2026.pptx

**Treatment:** Reference/extract; original binary not included  
**Version:** 7 Sep 2026 19:58:42 UTC  
**Included record:** [S02_Deck_Reference_Brief.md](Reference_Briefs/S02_Deck_Reference_Brief.md)  
**Source locator:** file_00000000be648210a9b376de43f0e1d1  
**Use:** Latest deck reference; source binary not included

## S02a — NutriSync PPT August 2026 (3).pdf

**Treatment:** Reference/extract; original binary not included  
**Version:** 6 Aug 2026  
**Included record:** [S02_Deck_Reference_Brief.md](Reference_Briefs/S02_Deck_Reference_Brief.md)  
**Source locator:** file_0000000044c481f4a40afa67b22ad0b6  
**Use:** Historical comparator only

## S03 — NutriSync_10_Types_Innovation_Proposal.pptx and PDF

**Treatment:** Reference/extract; original binary not included  
**Version:** 6 Aug 2026  
**Included record:** [S03_Innovation_Reference_Brief.md](Reference_Briefs/S03_Innovation_Reference_Brief.md)  
**Source locator:** file_0000000010b881fb9b68d6243f9dd02d  
**Use:** Segment-of-one and innovation system

## S03a — Ten Types introduction and overlay presentations

**Treatment:** Reference/extract; original binary not included  
**Version:** 6 Aug 2026  
**Included record:** [S03_Innovation_Reference_Brief.md](Reference_Briefs/S03_Innovation_Reference_Brief.md)  
**Source locator:** file_00000000dcc481fd8055ca844f533ebb; file_00000000b80882308b14e362d1acb9f6  
**Use:** Ten-type overlay; original slide binaries not included

## S04 — NutriSync_Competitor_Capability_Research.md

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S04_Competitor_Capability_Research.md](Full_Originals/S04_Competitor_Capability_Research.md)  
**Source locator:** https://drive.google.com/file/d/1UUIPMFCy6vyoELg0uLJsPcy4ppqDHd7I/view  
**Use:** 20 August competitor research; not a fresh exhaustive audit

## S05 — NutriSync_Commercial_Partner_Radar_v1_0_Aug2026.docx

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S05_Commercial_Partner_Radar_v1_0.docx](Full_Originals/S05_Commercial_Partner_Radar_v1_0.docx)  
**Source locator:** https://docs.google.com/document/d/1fyzQ3UnlTwY1B77OWQkcRrdgQhDqAvAd/edit  
**Use:** 13 August company write-up and partner programme; prospects not commitments

## S06 — NutriSync_Vision_Mission_Strategy.docx

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S06_Vision_Mission_Strategy.docx](Full_Originals/S06_Vision_Mission_Strategy.docx)  
**Source locator:** https://docs.google.com/document/d/1hZ-jn_GjJ6akd0DADIzOPRO4BGAR6RUa/edit  
**Use:** Strategic continuity and historical assumptions

## S07 — New Pitch Deck and Financial Model Review-Feedback.pdf

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S07_Deck_and_Financial_Model_Review.pdf](Full_Originals/S07_Deck_and_Financial_Model_Review.pdf)  
**Source locator:** https://drive.google.com/file/d/1B2CeSwBkXeFzIMz7KKpzgI15KSnGJ_TI/view  
**Use:** Earlier review and corrections; no new full audit implied

## S08 — NUTRISYNC_financial_model_rebuilt.xlsx

**Treatment:** Reference/extract; original binary not included  
**Version:** Version/date requires owner confirmation  
**Included record:** [S08_Rebuilt_Model_Reference_Brief.md](Reference_Briefs/S08_Rebuilt_Model_Reference_Brief.md)  
**Source locator:** file_00000000db8471fd87610bb9b9c5542c  
**Use:** Historical model financing and validation assumptions

## S08a — NutriSync Finance

**Treatment:** Full Google Sheets export (not rebuilt model)  
**Version:** See original document and main Annex A  
**Included record:** [S08a_NutriSync_Finance_Drive_Export.xlsx](Full_Originals/S08a_NutriSync_Finance_Drive_Export.xlsx)  
**Source locator:** https://docs.google.com/spreadsheets/d/1zKHMbQW6ZG3xrr8X0x9_rfML3t_AAcBIyLHvMnmmGzA/edit  
**Use:** Earlier Google Sheets finance file, distinct from rebuilt workbook

## S09 — Legal project record and README

**Treatment:** Reference/extract; original binary not included  
**Version:** 4 Aug 2026  
**Included record:** [S09_Legal_and_Corporate_Reference_Brief.md](Reference_Briefs/S09_Legal_and_Corporate_Reference_Brief.md)  
**Source locator:** file_0000000091a481f7a91b48c1961975d3; file_0000000003f881f7b180f9fd46fda503  
**Use:** Counsel-review document register

## S09a — Counsel brief and bilingual counsel-review set

**Treatment:** Reference/extract; original binary not included  
**Version:** 4 Aug 2026  
**Included record:** [S09_Legal_and_Corporate_Reference_Brief.md](Reference_Briefs/S09_Legal_and_Corporate_Reference_Brief.md)  
**Source locator:** file_00000000f4fc81f7a737e5d3deec484f  
**Use:** Legal release dependencies; not legal approval

## S09b — NutriSync_Collective_Guia_CB_vs_SL_Madrid_ES.docx

**Treatment:** Reference/extract; original binary not included  
**Version:** 13 Aug 2026  
**Included record:** [S09_Legal_and_Corporate_Reference_Brief.md](Reference_Briefs/S09_Legal_and_Corporate_Reference_Brief.md)  
**Source locator:** file_0000000070d481f9ad6e20823ef58478  
**Use:** Corporate/IP planning reference

## S10 — Draft-Plan-Lanzamiento-8Oct-v2 (1).html

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S10_Launch_Plan_8Oct_v2.html](Full_Originals/S10_Launch_Plan_8Oct_v2.html)  
**Source locator:** https://drive.google.com/file/d/1p8-WNrIjuJvT3eXOvY5Q9x8L5cn5vSHx/view  
**Use:** Historical launch plan; dates not reconfirmed

## S11 — Meeting 1 with Tony and founder instructions

**Treatment:** Reference/extract; original binary not included  
**Version:** User supplied in this conversation  
**Included record:** [S11_Tony_and_Founder_Brief.md](Reference_Briefs/S11_Tony_and_Founder_Brief.md)  
**Source locator:** Conversation source  
**Use:** Scope, capital levels and international candidates

## S12 — 371d9e99-88c3-4ad4-8e58-802d0e5b1f88.png

**Treatment:** Full original  
**Version:** See original document and main Annex A  
**Included record:** [S12_User_Supplied_Oura_Context.png](Full_Originals/S12_User_Supplied_Oura_Context.png)  
**Source locator:** User attachment in this conversation  
**Use:** Source screenshot; not evidence that litigation allegations are proved

