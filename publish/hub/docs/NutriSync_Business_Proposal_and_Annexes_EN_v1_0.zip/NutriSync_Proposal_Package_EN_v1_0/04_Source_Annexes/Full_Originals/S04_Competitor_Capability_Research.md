# Competitor Capability Research — for Slide 6 ("The NutriSync Difference")
*Researched live (web search + official sources) on 2026-08-20. Sourced per-dimension notes below the summary grid. A couple of cells carry a verification caveat, flagged where relevant — worth a quick manual re-check before you put a claim in front of judges.*

## Summary grid

| Dimension | Wild.AI | Hormona | Harmony | 28 | NC° (Natural Cycles) | Flo Living | Clue | Flo |
|---|---|---|---|---|---|---|---|---|
| 1. Science-backed cycle-sync framework | **Yes** | **Yes** | Somewhat | Somewhat | **Yes** | Somewhat | Somewhat | Somewhat |
| 2. Ethical data & privacy by design | Somewhat | Somewhat | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** |
| 3. Integrated cycle, nutrition & fitness plans | **Yes** | **Yes** | **Yes** | **Yes** | No | **Yes** | No | No |
| 4. AI personalization | Somewhat | Somewhat | Somewhat | Somewhat | **Yes** | Somewhat | Somewhat | Somewhat |
| 5. Social & community features | Somewhat | **Yes** | Somewhat | Somewhat | No | Somewhat | Somewhat | **Yes** |
| 6. Direct-to-consumer | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** |
| 7. Institutional ATL outreach | Somewhat | Somewhat | No | Somewhat | Somewhat | Somewhat | **Yes** | **Yes** |
| 8. TTL data & insight loop | No | **Yes** | No | No | **Yes** | Somewhat | **Yes** | **Yes** |

---

## Bottom line: yes, two rows are actively hurting your slide, and two more are weak

**Remove "Direct-to-consumer."** All eight companies sell D2C via app subscription — this dimension has zero spread across your whole comparison set. Including it doesn't make NutriSync look more differentiated, it makes the slide look padded, and a sharp judge will clock that in about two seconds ("wait, isn't that just... every app?").

**Reframe or cut "AI personalization."** Every single competitor markets some form of "AI" — Wild.AI, Hormona, Harmony, 28, Flo Living, Clue and Flo all landed at "Somewhat" (marketing claims an AI layer, but none publish real technical detail on adaptive per-user ML), and NC° is the only clean "Yes" (FDA-cleared AI fertility algorithm). Since "we have AI" is table stakes messaging across the entire category now, a flat Yes/Somewhat comparison doesn't buy you anything. Better to replace this row with something none of them can currently claim: an *outcome-measured* personalization loop — i.e., not "we use AI" but "we can show a specific recommendation led to a specific measured change for that person." That's a claim only NutriSync can make once you have pilot data, and it's much harder for a competitor to copy-paste in marketing copy.

**Weak, consider cutting: "Ethical data & privacy by design."** Five of eight (Harmony, 28, NC°, Flo Living, Clue, Flo — actually six) have explicit "we never sell your data" language, GDPR sections, and in some cases certifications (Flo has ISO 27001/27701, NC° cites FDA cybersecurity compliance, Clue has a DPO and EU-only servers). This has become baseline hygiene in the category post-Flo's 2021 FTC settlement, not a differentiator. Keep it if you want a slide that shows category-wide table stakes, but don't lean on it as a competitive edge.

**Weak, consider cutting or merging: "Social & community features."** Mixed and mostly partial everywhere — 1:1 sharing (Clue Connect, 28's Partner Sharing), anonymous chat (Flo's Secret Chats), light community pages (Hormona). Nobody has a strong, unique claim here including you; not worth its own row.

**Keep — this one is real: "Institutional ATL outreach."** Only Clue and Flo (the two category giants) have genuine large-scale institutional/press/partnership reach. Every smaller, newer competitor closer to your stage — Wild.AI, Hormona, Harmony, 28 — is doing performance/social marketing, not ATL. This is legitimate whitespace against the companies you're actually sized like.

**Keep, but reframe carefully: "TTL data & insight loop."** This is the most important one to get right, because the data doesn't fully support the claim as currently framed. Clue has an extensive, genuinely impressive research program — 25+ published papers, partnerships with Oxford, Stanford, MIT, Johns Hopkins, the Gates Foundation, built on 750M+ logged cycles. NC° has its own public research library with population-scale studies. Even Hormona, despite being much earlier-stage than you might expect, has already published three papers from 1.5M+ data points. If your slide implies NutriSync is uniquely building a data/insight loop, that's contestable against at least three of your eight comparison points. What nobody else is doing — including Clue — is a *personal* recommend → act → measure → recalibrate loop tied to individual outcomes rather than population-level retrospective research. That's a real distinction in kind, not just existence, and it's worth making that precise instead of the current framing.

**Add Wild.AI and Hormona to the actual comparison table.** These are your two closest competitors and neither currently appears on your named comparison slide. Wild.AI in particular is uncomfortably close to your positioning: it cites "451 scientific whitepapers," has Dr. Stacey Sims as a science partner, and — as of an August/September 2025 acquisition — is now backed by Zepp Health/Amazfit, giving it hardware distribution you don't have. Leaving your closest competitor off a competitive-landscape slide reads as either an oversight or an evasion; naming it and showing where you still differ (the individual outcome-loop point above) is more credible than omitting it.

**Consider adding Harmony as a fast-mover to watch, if space allows.** It's new (developed by Paris-based Rocapine, which just raised a $13M Series A), already has 110,000+ users, and is explicitly AI-native and cycle/nutrition/fitness integrated — structurally similar to your pitch. It doesn't have institutional outreach or a data/insight loop yet (both "No"), so it's not a threat on your strongest ground, but it's worth having on your radar even if it doesn't make the final slide.

---

## Detailed sourced notes by company

### Wild.AI
*Acquired by Zepp Health/Amazfit (Aug–Sep 2025); continues as a standalone app plus wearable integration.*

1. **Science-backed cycle-sync framework — Yes.** Publicly claims its algorithm is built on 451+ scientific whitepapers on female physiology, developed with Dr. Stacey Sims. Sources: [wild.ai/about](https://wild.ai/about), [Medium — 451 whitepapers](https://medium.com/wild-push-your-limits-and-live-all-extremes/how-we-turned-451-white-papers-on-female-physiology-into-the-most-powerful-algorithm-turning-raw-b868e9ac1202)
2. **Ethical data & privacy — Somewhat.** Markets 4 privacy promises, but the actual privacy policy is thinner (no explicit no-sale clause, no HIPAA mention). Sources: [wild.ai/about](https://wild.ai/about), [wild.ai/privacy-policy](https://www.wild.ai/privacy-policy)
3. **Integrated nutrition + fitness — Yes.** App Store confirms both nutrition and training/recovery guidance. Source: [App Store](https://apps.apple.com/us/app/wild-ai-hormones-fitness/id1482294997)
4. **AI personalization — Somewhat.** Markets "AI" and a readiness score, but no confirmation of adaptive per-user ML. Sources: App Store listing, [wild.ai/faqs](https://www.wild.ai/faqs)
5. **Social & community — Somewhat.** A community exists at community.wild.ai but isn't a core in-app feature. Source: [community.wild.ai](https://community.wild.ai/home)
6. **Direct-to-consumer — Yes.** $14.99/mo or $79.99/yr via App Store/Google Play.
7. **Institutional ATL — Somewhat.** Wide press on the Zepp Health acquisition, investor backing, Amazfit device partnership — but no university/sports-federation/brand-campaign evidence. Sources: [Businesswire](https://www.businesswire.com/news/home/20250904422306/en/Zepp-Health-Acquires-Core-Assets-of-Wild.AI-to-Expand-Support-for-Female-Athletes-Across-Life-Stages), [fitt.co](https://insider.fitt.co/startup-qa-wild-ai-founder-helene-guillaume-pabis/)
8. **TTL data & insight loop — No.** No published white papers or studies from Wild.AI's own user data found — the "451 whitepapers" are external literature it synthesizes, not original research.

### Hormona
1. **Science-backed cycle-sync framework — Yes.** Endocrinologist/gynecologist/nutritionist advisory board, a Research page listing published studies, plus 3 self-published academic papers from 1.5M+ anonymized data points. Sources: [hormona.io/pages/our-story](https://www.hormona.io/pages/our-story), [hormona.io/research](https://www.hormona.io/research/), [tech.eu](https://tech.eu/2024/04/17/hormona-bridges-the-gender-data-gap-in-hormonal-health-going-beyond-baby-making/)
2. **Ethical data & privacy — Somewhat.** App Store claims data is "never shared without consent," but the site's privacy-policy URL 404'd and the Play Store Data Safety tab was blocked during this check — worth a manual re-verify before quoting.
3. **Integrated nutrition + fitness — Yes.** Cycle-phase nutrition/recipes plus phase-based exercise guidance. Source: [App Store](https://apps.apple.com/us/app/hormona-period-hormones/id1589458330)
4. **AI personalization — Somewhat.** "Advanced algorithms" language, no stated ML methodology.
5. **Social & community — Yes.** In-app community/expert Q&A, plus in-person events in Sweden/UK/Netherlands. Sources: App Store listing, [hormona.io/pages/events](https://www.hormona.io/pages/events)
6. **Direct-to-consumer — Yes.** App + purchasable at-home hormone test kits.
7. **Institutional ATL — Somewhat.** $6.7M seed (Voima Ventures, 2025), employer wellness-scheme partnerships in UK/Sweden, presented at a NASA-adjacent human-performance summit — but no university research partnerships or major press/brand campaigns at scale. Sources: [tech.eu](https://tech.eu/2024/04/17/hormona-bridges-the-gender-data-gap-in-hormonal-health-going-beyond-baby-making/), [voimaventures.com](https://voimaventures.com/unlocking-the-power-of-science-to-give-women-the-clarity-theyve-always-deserved-around-hormones-voima-ventures-leads-6-7m-seed-round-in-hormona/)
8. **TTL data & insight loop — Yes.** 1.5M+ anonymized data points collected since 2023, 3 published papers, findings feed back into product. Source: [hormona.io/research](https://www.hormona.io/research/)

### Harmony (Rocapine)
*Disambiguation: this is "Harmony — Cycle Syncing, Period App," built by Rocapine, a Paris-based AI-native wellness app studio — not any of the unrelated healthcare/finance products sharing the name.*

1. **Science-backed cycle-sync framework — Somewhat.** Standard 4-phase model, "grounded in hormonal research," but no named advisors or published validation.
2. **Ethical data & privacy — Yes.** Explicit no-sale policy, GDPR/CCPA sections, AES-256 encryption. Source: harmony-cycle.app/privacy
3. **Integrated nutrition + fitness — Yes.** Phase-specific food and workout-intensity guidance in one app.
4. **AI personalization — Somewhat.** Markets an "AI Lifestyle Assistant" chat coach, no technical depth published.
5. **Social & community — Somewhat.** "Harmony Together" partner-connection feature; no open forum.
6. **Direct-to-consumer — Yes.** $9.99–$59.99 subscriptions, 7-day trial.
7. **Institutional ATL — No.** Rocapine's own stated strategy is explicitly "mobile-gaming-style, performance marketing" — no institutional partnerships found. Sources: [Femtech Insider](https://femtechinsider.com/french-wellness-app-studio-rocapine-raises-13m-to-scale-ai-built-apps-including-cycle-tracker-harmony/), [tech.eu](https://tech.eu/2026/06/16/rocapine-raises-13m-series-a-to-scale-its-wellness-app-portfolio/)
8. **TTL data & insight loop — No.** No published research found; press coverage is about download/ARR growth, not research output.

### 28
1. **Science-backed cycle-sync framework — Somewhat.** "Patent-pending algorithm" and "medical expert"-designed content claimed, but no named advisors or published studies. Sources: [App Store](https://apps.apple.com/us/app/28-ai-period-tracker-health/id6443715544), [Grazia](https://graziamagazine.com/us/articles/how-the-28-app-is-providing-a-wellness-compass-to-cycle-synching-and-optimizing-womens-health/)
2. **Ethical data & privacy — Yes.** Explicit no-sale/no-ad-use of health data, encryption at rest and in transit — though only US state law is cited, not GDPR, and no named security certification. Source: [28.co/privacy](https://28.co/privacy)
3. **Integrated nutrition + fitness — Yes.** Phase-based workout videos and nutrition guidance together.
4. **AI personalization — Somewhat.** "AI-powered" nutrition/photo-calorie features marketed, but Google Play notes the core phase algorithm is manually set by the user rather than adaptive.
5. **Social & community — Somewhat.** No in-app forum; "Partner Sharing" and an ambassador/affiliate "Collective" program, not peer community.
6. **Direct-to-consumer — Yes.** $19.99/mo up to $119.99/yr tiers.
7. **Institutional ATL — Somewhat.** Organic/TikTok-driven growth strategy per cofounder interview, real earned press (Grazia, Evie Magazine), $3.2M seed — but no university/employer/sports-federation partnerships. Sources: [Grazia](https://graziamagazine.com/us/articles/how-the-28-app-is-providing-a-wellness-compass-to-cycle-synching-and-optimizing-womens-health/), [Evie Magazine](https://www.eviemagazine.com/post/28-evies-cycle-based-wellness-company-launches-with-usd3-2m-in-funding)
8. **TTL data & insight loop — No.** No published research from 28's own data found.

### NC° (Natural Cycles)
*Disambiguation: "NC°" is the current brand mark for Natural Cycles (Naturens AB), the Swedish FDA-cleared birth-control/fertility app, rebranded under this degree-symbol logo in 2025 alongside a new wearable ("NC° Band").*

1. **Science-backed cycle-sync framework — Yes.** FDA-cleared (6 clearances), 30+ published studies, named Medical Advisory Board. Sources: [naturalcycles.com/the-science](https://www.naturalcycles.com/the-science), [research-library](https://www.naturalcycles.com/research-library)
2. **Ethical data & privacy — Yes.** No-sale policy, GDPR-compliant since founding, "Go Anonymous" identity-decoupling mode, FDA cybersecurity compliance.
3. **Integrated nutrition + fitness — No.** Temperature/cycle/mood/sleep tracking and wearable integration, but no nutrition guidance and no fitness programming.
4. **AI personalization — Yes.** FDA's 6th clearance was specifically for an "AI-Powered Fertility Algorithm" adapting to each user's own temperature data. Source: [Femtech Insider](https://femtechinsider.com/natural-cycles-receives-sixth-fda-clearance-for-ai-powered-fertility-algorithm/)
5. **Social & community — No.** No in-app forum/community found.
6. **Direct-to-consumer — Yes.** Subscription plus purchasable NC° Band hardware.
7. **Institutional ATL — Somewhat.** Heavy press on FDA clearances, a nonprofit partnership (The Pad Project), a documented large-scale UK/Sweden brand-awareness campaign (127% registration lift) — but that campaign is paid-social/TV, not classic university/employer ATL. Source: [Campaign Live](https://www.campaignlive.co.uk/article/naturally-creative-natural-cycles-marketing-campaign-achieved-massive-uplift-brand-awareness/1485230)
8. **TTL data & insight loop — Yes.** Dedicated Research Library, studies on 540,000+ cycles, feeds directly into product features like Perimenopause mode.

### Flo Living
*Disambiguation: floliving.com / Alisa Vitti's Cycle Syncing® coaching platform and myFLO app — a different company from the Flo Health period-tracker below, despite the similar name.*

1. **Science-backed cycle-sync framework — Somewhat.** Claims "20 years of research," MD testimonials (Aviva Romm, Mark Hyman, others), but no peer-reviewed citations or listed advisory board on the public site.
2. **Ethical data & privacy — Yes.** Explicit no-sale policy, dedicated GDPR section. Source: [floliving.com/pages/privacy-policy](https://floliving.com/pages/privacy-policy)
3. **Integrated nutrition + fitness — Yes.** Phase-based diet/recipes plus phase-based fitness videos (including an Obe Fitness integration).
4. **AI personalization — Somewhat.** "Hormonal health assessment" feeding a recommendation engine; no AI/ML terminology used in official materials.
5. **Social & community — Somewhat.** No in-app community; a public Facebook group exists.
6. **Direct-to-consumer — Yes.** Website subscriptions plus the myFLO app.
7. **Institutional ATL — Somewhat.** Strong media presence (Dr. Oz, Fox News, CBS, Yahoo Health advisory board), but no university/employer/sports-federation partnerships found.
8. **TTL data & insight loop — Somewhat.** Announced (not yet published) clinical trial partnership with Mira, Hello Inside and Citruslabs to validate the Cycle Syncing Method — still in data-collection phase, no completed study yet. Source: [Yahoo Finance](https://finance.yahoo.com/news/flo-living-partners-leading-femtech-200900439.html)

### Clue
1. **Science-backed cycle-sync framework — Somewhat.** Genuine scientific credibility (Head of Science, CMO, CE-marked medical device, ACOG's top-rated tracker) — but Clue's own published content states cycle-syncing research is "limited and oftentimes conflicting," and the app doesn't deliver phase-based recommendation content at all; it's tracking/prediction/education, not a cycle-sync methodology. Source: [helloclue.com/about-clue](https://helloclue.com/about-clue)
2. **Ethical data & privacy — Yes.** Explicit no-sale pledge, EU-only servers, GDPR compliance, appointed DPO, states it would refuse data subpoenas.
3. **Integrated nutrition + fitness — No.** No native nutrition/workout plans; fitness content is outsourced via a FitOn partnership, not an integrated phase-based plan.
4. **AI personalization — Somewhat.** Clue Plus markets insights that "get smarter the more you track," no public ML architecture detail.
5. **Social & community — Somewhat.** "Clue Connect" is 1:1 data sharing with one partner/friend, not an open community.
6. **Direct-to-consumer — Yes.** 1M+ paid subscribers, 10M monthly active users, 190+ countries.
7. **Institutional ATL — Yes.** TIME "50 Genius Companies" (2018), ACOG endorsement, B2B2C employer/healthcare partnerships, national press-released brand campaigns.
8. **TTL data & insight loop — Yes.** "Clue Science" program: 40+ research collaborations, 25+ published papers, partnerships with Oxford, Stanford, Johns Hopkins, MIT, the Gates Foundation, built on 750M+ logged cycles. Source: [helloclue.com/landing/scientific-research](https://helloclue.com/landing/scientific-research)

### Flo
*Disambiguation: flo.health (Flo Health Inc.) — the large period/ovulation tracker, distinct from Flo Living above.*

1. **Science-backed cycle-sync framework — Somewhat.** 140+ doctor content team, named "Experts Board," a published RCT on health-literacy improvement — but this validates content accuracy, not a distinct cycle-sync physiological methodology (that trademarked concept belongs to Flo Living, a separate company).
2. **Ethical data & privacy — Yes.** No-sale pledge, GDPR since 2018, ISO 27001/27701 certifications, "Anonymous Mode" (open-sourced), and a publicly documented response (independent audit, dedicated "privacy journey" page) to its 2021/2022 FTC and related settlements over pre-2019 ad-data sharing. Source: [flo.health/our-privacy-journey](https://flo.health/our-privacy-journey)
3. **Integrated nutrition + fitness — No.** General wellness tips and energy predictions, no structured cycle-phase nutrition + training program.
4. **AI personalization — Somewhat.** Markets "AI-powered predictions" and a chatbot "Flo Health Assistant," but official docs describe it more as rule-based + ML pattern detection than confirmed adaptive personalization.
5. **Social & community — Yes.** "Secret Chats," an active anonymous community feature with ~7M monthly participants.
6. **Direct-to-consumer — Yes.** Flo Premium subscription via App Store/Google Play.
7. **Institutional ATL — Yes.** Mayo Clinic co-published perimenopause study (17,494 users, 158 countries), a Privacy & Security Advisory Board, consistent major press coverage.
8. **TTL data & insight loop — Yes.** Publishes population-level studies (Mayo Clinic perimenopause study, global orgasm study, global mental-health/perimenopause study) via its newsroom and med.flo.health research arm.
