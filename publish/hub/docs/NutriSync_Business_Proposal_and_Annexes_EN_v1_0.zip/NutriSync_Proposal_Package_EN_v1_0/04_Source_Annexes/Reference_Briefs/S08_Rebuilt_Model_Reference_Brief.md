# S08 — Rebuilt financial model source brief

**Treatment: selected reference/extract, not the original workbook and not a full audit.**

Source: `NUTRISYNC_financial_model_rebuilt.xlsx`, Library ID `file_00000000db8471fd87610bb9b9c5542c`. Metadata predates some content, so no precise last-authoritative-version claim is made.

## Retrieved financing assumptions

| Financing input | Conservative | Realistic | Ambitious |
|---|---:|---:|---:|
| Opening / pre-seed cash | EUR 350,000 | EUR 350,000 | EUR 350,000 |
| Month-13 seed | EUR 1,200,000 | EUR 1,800,000 | EUR 2,500,000 |
| Month-25 further round | EUR 0 | EUR 3,000,000 | EUR 6,000,000 |

These are historical model assumptions, not secured investments. They explain why source forecasts must not be presented as achievable with only EUR 350K or as a no-external-investment runway.

## Model principles carried forward

The source separates financing from revenue, monthly flows from endpoint run rates, upgrades from unique customers, and B2B contracts/seats from active people. Its notes flag unvalidated conversion, wearable-retention uplift and acquisition assumptions.

## Limits

No claim is made that every source formula has been recalculated or repaired. The accompanying `NutriSync_Capital_and_GTM_Planning_EN_v1_0.xlsx` is a new, transparent budget and stress-test schedule; it is not this rebuilt workbook.

The full Google Sheets export included as S08a is a different earlier file. Its presence must not be used to imply that the full S08 binary has been attached.
