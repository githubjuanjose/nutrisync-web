# S09 / S09a / S09b — Legal, privacy and corporate source brief

**Treatment: reference/extract, not a complete legal-document pack or legal sign-off.**

## Source records

The 4 August 2026 `NutriSync_Project_Record_Chat_Summary_and_Amendment_Log.docx` (Library ID `file_0000000091a481f7a91b48c1961975d3`) and `NutriSync_Project_Index_README.md` (`file_0000000003f881f7b180f9fd46fda503`) identify the final counsel-review set. The counsel brief is `NutriSync_Counsel_Review_Brief_Controller_Cookies_Transfers.docx` (`file_00000000f4fc81f7a737e5d3deec484f`).

The referenced bilingual package is `NutriSync_Final_Counsel_Review_Set_ES_EN.zip` (stable Library record `libfile_756ba1405db0819196a65a4b7c006f3`); the complete ZIP binary is not included here.

The register includes English and Spanish beta agreement, health notice, explicit health-data consent, cookie/storage/SDK policy and privacy policy. English filenames include:

- `NutriSync_Private_Beta_Agreement_EN_Final_Counsel_Review.docx`
- `NutriSync_Health_Notice_EN_Final_Counsel_Review.docx`
- `NutriSync_Explicit_Health_Data_Consent_EN_Final_Counsel_Review.docx`
- `NutriSync_Cookie_Storage_and_SDK_Policy_EN_Final_Counsel_Review.docx`
- `NutriSync_Privacy_Policy_EN_Final_Counsel_Review.docx`

Corporate source: `NutriSync_Collective_Guia_CB_vs_SL_Madrid_ES.docx`, 13 August 2026, Library ID `file_0000000070d481f9ad6e20823ef58478`.

## Relevant retrieved findings

The counsel-review record calls for confirmation of the controller's legal name, registration number and address; cloud processing/transfer safeguards; consent; retention/deletion; security; applicable age/consumer terms; and assessment of intended medical purpose. It distinguishes primary EU storage from global edge activity, overseas update processing, remote access and onward processing.

The historical technical inventory said no active analytics or advertising SDK was behind some future-facing controls. A new marketing programme must not silently activate those functions. Corporate/IP assignments, ownership, contracting and actual company status require confirmation.

## Use and preservation

Sections 12–15, 18 and Annex H treat legal/compliance as a budgeted dependency, not a certification supplied by cloud hosting. Original legal drafts must retain their own version history; this business proposal does not edit or approve them. Actual launch and country obligations must be assessed by qualified advisers against implemented functions.
