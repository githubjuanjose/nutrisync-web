# S11 — User-supplied meeting and founder instructions

**Treatment: structured summary of conversation inputs, not a verbatim transcript.**

Tony's principal reported questions were (1) what EUR 2M or EUR 5M would concretely accelerate and (2) how NutriSync would take a reasonable share of the market beyond TAM/SAM/SOM. The notes also called for investor-return scenarios and a point of view on valuation and instruments.

The user asked for three modest, realistic financing levels—EUR 15–25K, EUR 250–350K and EUR 2–5M—and a clear position that the team intends to progress using its own capacity with or without investment. Nutrition and exercise, rich expert content, distribution and marketing must remain equally visible.

The business is cloud-based. International exploration is not Europe-only: Australia and Singapore are candidates, not committed launches. The user reports that Lucía is Singapore PR and knows digital-sector firms there. Potential government support must be screened for actual eligibility and cannot be assumed secured.

The notes do not establish an investment commitment, cheque size or signed term sheet. Tony's reported investment record is unverified and is not used as endorsement. Reported diligence timing is not treated as a cash-receipt date.
