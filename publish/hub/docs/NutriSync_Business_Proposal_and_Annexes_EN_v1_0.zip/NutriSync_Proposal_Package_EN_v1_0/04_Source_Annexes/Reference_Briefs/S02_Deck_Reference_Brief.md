# S02 / S02a — Pitch deck source brief

**Treatment: reference/extract, not the original PPTX or PDF.**

The current source is `NutriSync PPT Aug 2026.pptx`, uploaded 7 September 2026 at 19:58:42 UTC. Library ID: `file_00000000be648210a9b376de43f0e1d1`. The earlier copy uploaded at 19:42:16 UTC is not separately attached as a current version.

The older `NutriSync PPT August 2026 (3).pdf`, Library ID `file_0000000044c481f4a40afa67b22ad0b6`, is a historical August comparator, not the latest deck.

## Relevant retrieved material

The current deck's opening proposition is adaptive nutrition, movement and recovery guidance that learns across cycles. Its system narrative connects cycle context, symptoms, nutrition/movement logs and biometrics to a personal baseline, guidance and learning. It contains Cycle Alignment and Cycle Stability concepts. These are design concepts, not a certification of clinical validity.

The deck presents historical price propositions of EUR 4.99 Basic, EUR 12.99 Premium and EUR 3.99 B2B per month. Its funding slide shows EUR 350K while speaker notes retain EUR 250K. Different main and appendix scenarios remain to be reconciled. The main business proposal treats EUR 250–350K as a range of possible scopes and does not adopt a historic forecast as audited.

Demand, interview, audience, pilot and partnership statements need current evidence. A targeted audience is not a signed customer; seats are not activated people. Wearable-related retention, market access and API-cost assertions require source/contract validation.

## Use in the proposal

The source informs the value proposition, funding reconciliation, pricing discipline and Annex E. The source deck is not edited or replaced by this brief. Its full binary was not available in the working download set.
