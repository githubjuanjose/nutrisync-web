# S03 / S03a — Ten Types innovation source brief

**Treatment: reference/extract, not the original slide files.**

## Source records

- `NutriSync_10_Types_Innovation_Proposal.pptx`, 6 August 2026. Library ID `file_0000000010b881fb9b68d6243f9dd02d`.
- PDF companion: `file_0000000019c481fdb1257b1ec840aaae`.
- `NutriSync_10_Types_Introduction_and_Overlay.pptx`, 6 August 2026. Library ID `file_00000000dcc481fd8055ca844f533ebb`.
- `NutriSync_10_Types_Overlay_One_Slide.pptx`, 6 August 2026. Library ID `file_00000000b80882308b14e362d1acb9f6`.

## Retained system proposition

The innovation proposal describes one segment-of-one learning system spanning nutrition, movement, recovery, symptoms and biometrics. Its loop is Sense → Interpret → Recommend → Measure → Learn. Cycle context is one input; the individual baseline and response are the intended basis for adaptation.

The four core innovation types are Process, Product Performance, Product System and Customer Engagement. Profit Model, Network, Structure, Service, Channel and Brand support the complete business. The original work identifies subscriptions/B2B/partners, employers/clinics/universities/wearables, governance, guided onboarding, events and community.

The source explicitly treats the individual-learning advantage as a design proposition until response data validates it. Statements such as four-plus innovation types or ten-of-ten ambition are heuristics, not certificates, success probabilities or return forecasts. Historical live/pilot/roadmap labels are not verified current readiness.

## Use in the proposal

Section 16 and Annex B retain the framework while avoiding unsupported competitor exclusivity. The business proposal applies eliminate–reduce–raise–create separately as a Blue Ocean design exercise, not proof of an uncontested market.
